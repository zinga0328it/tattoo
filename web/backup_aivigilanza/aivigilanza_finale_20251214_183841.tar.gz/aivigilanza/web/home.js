fetch("/api/log_ip?trap=ramkiller")
